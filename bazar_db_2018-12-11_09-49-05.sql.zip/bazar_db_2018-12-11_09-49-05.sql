-- MySQL dump 10.13  Distrib 5.1.73, for redhat-linux-gnu (x86_64)
--
-- Host: localhost    Database: bazar_db
-- ------------------------------------------------------
-- Server version	5.1.73

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `bazar_db`
--


--
-- Table structure for table `announcement`
--

DROP TABLE IF EXISTS `announcement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `announcement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `picture` varchar(255) NOT NULL,
  `product` varchar(255) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `price` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcement`
--

LOCK TABLES `announcement` WRITE;
/*!40000 ALTER TABLE `announcement` DISABLE KEYS */;
INSERT INTO `announcement` VALUES (10,33854740,'AgADAgADyakxGwnhiEqufb97nf0_HvZOqw4ABNlV2JQZYMuU4LkDAAEC','Test mahsulot','Sifatli screenshot','900$','+9988234234','sdfsdf','Zuxriddin Kamalov',1,1,'2018-07-19 16:48:42'),(12,33854740,'AgADAgAD4qkxGwnhiEqsZgdYv8nlxjDdtw4ABOGUXLju3aQ_rzcBAAEC','IDEA','Mahsulot uchun tarif','9000$','+99823232332','Toshkent','Zuxriddin Kamalov',0,1,'2018-07-19 17:34:19'),(13,33854740,'AgADAgAD5KkxGwnhiEoEMi6RzemKMIG8tw4ABMNdeQABhF_kigk5AQABAg','IDEA','IDEA php coding','800$','+9992939239','Buxoro viloyati G\'ijduvon tumani','Zuxriddin Kamalov',0,1,'2018-07-19 17:51:43'),(14,33854740,'AgADAgAD5akxGwnhiEr748oPoysDk-S-tw4ABMYGJR0cTwkqYzsBAAEC','PHP','Lorem ipsum deler set amet','9000%','+9988888234','Toshkent shahri','Zuxriddin Kamalov',0,1,'2018-07-19 17:53:58'),(15,598294767,'AgADBAADwqcxGzKXFVJrNC7zDfc6_MkEkRkABE3Xw7Y9p5DlZ2QDAAEC','Infobiznes','Infobiznes sirlari haqida kurs','10$','+998999999999','','ℳaŋagεr [FutSoft] © ',0,1,'2018-07-19 18:14:56'),(16,33854740,'AgADAgAD5qkxGwnhiEo_3dJ9Ccu_fRJQqw4ABNEU1UA3fOaWB7cDAAEC','Intellij idea','Intellej PHP storm muhiti','800$','+99828383282323','Toshkent shahri','Zuxriddin Kamalov',0,1,'2018-07-19 18:48:09'),(17,598294767,'AgADBAADwqcxGzKXFVJrNC7zDfc6_MkEkRkABE3Xw7Y9p5DlZ2QDAAEC','Infobiznes','Infobiznes sirlari haqida kurs','20$','+998977777777','Toshkent','ℳaŋagεr [FutSoft] © ',0,1,'2018-07-19 18:52:19'),(18,598294767,'AgADBAADwqcxGzKXFVJrNC7zDfc6_MkEkRkABE3Xw7Y9p5DlZ2QDAAEC','Biznes sirlari','Boy bo\'lish va biznes boshlash sirlari','10$','+998999999999','Toshkent','ℳaŋagεr [FutSoft] © ',0,1,'2018-07-22 17:40:06'),(19,102641152,'AgADAgADHKkxGyIAATlLYHFCFYImvdmXuqsOAAQ1g2yRl8fIqi5KBAABAg','Mustaqilligimizning 27 yilligi','Buni sotmeman shunde bervoraman','0000 so\'m','+998931234567','','βоγvลĉჩĉჩล ',0,1,'2018-08-05 07:41:32'),(20,509148157,'AgADAgADIqkxGwwj8UpVBn6_AAGw7014xUYOAASdj_xZ1-alvHuZBAABAg','Nothing','Cool','5000 som','8293739','','Jakhongirmirzo ',0,1,'2018-08-05 13:50:33'),(21,33854740,'AgADAgADuqgxG5a5UEsmdAg_j1CJYVu6tw4ABLsdtro89ySWnOMBAAEC','browser','Testing description','400$','+998324234','Toshkent shahri, Olmazor tumani Bekboshi qishlog\'i','Zuxriddin Kamalov',0,1,'2018-08-07 09:48:21'),(22,33854740,'AgADAgADvagxG5a5UEt1hpgdYdFWFpPNtw4ABFf-ew3rwtf9BuQBAAEC','GSM modem','GSM modem modern','4000$','+99823423443434','','Zuxriddin Kamalov',0,1,'2018-08-07 10:18:08'),(23,66441062,'AgADAgADrakxG5DKUUvI1oLiTg27gxfKtw4ABPFuYPCNIuuSn-cBAAEC','Кинг','Test','100','1111','','Rustam ',0,0,'2018-08-07 18:05:59'),(25,33854740,'AgADAgAD5akxG9_JAAFIE0sSHoTKYHguY6sOAATRjjK8T8WD1_UPBQABAg','Windows explorer win 10 edition','Explorer for windows 10. For exploring files','900$','+998323234234234','Toshkent shahri','Zuxriddin Kamalov',0,1,'2018-08-24 10:16:53'),(26,598294767,'AgADAgADEakxGw8_IUjov-DjPdFSQSYqrQ4ABIML5fi-HMiqfjIFAAEC','Stadion','Germaniyaning Bavariya Myunxen stadioni sotiladi. Holati zo\'r. +Bonusga Noer qo\'shib beriladi','1$','+998999999999','Toshkent','ℳaŋagεr [FutSoft] © ',0,0,'2018-08-27 09:03:51'),(27,275465113,'AgADAgAD_qkxGwarcEqN3gt4BBk3KFa0tw4ABbKFGJ5Mh886gwUAAQI','asdwD','Wdfefr','265','9845984','','X Khan',0,1,'2018-10-22 12:43:33');
/*!40000 ALTER TABLE `announcement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_tokens`
--

DROP TABLE IF EXISTS `auth_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_tokens` (
  `token` varchar(256) NOT NULL,
  `ip` varchar(15) NOT NULL,
  `experience_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `user` int(11) NOT NULL,
  PRIMARY KEY (`user`),
  KEY `token` (`token`(255))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_tokens`
--

LOCK TABLES `auth_tokens` WRITE;
/*!40000 ALTER TABLE `auth_tokens` DISABLE KEYS */;
INSERT INTO `auth_tokens` VALUES ('eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VybmFtZSI6ImFkbWluaXN0cmF0b3IiLCJpZCI6IjEiLCJpYXQiOjE1MzMxMTYxNTksImV4cCI6MTUzMzEzNDE1OX0.Z_fwm39Ab-KBHa8zfhpPjuf-AAwHwrvjf57INR-xrQg','178.218.202.35','0000-00-00 00:00:00',1);
/*!40000 ALTER TABLE `auth_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groups`
--

LOCK TABLES `groups` WRITE;
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
INSERT INTO `groups` VALUES (1,'admin','Administrator'),(2,'members','General User');
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `limits`
--

DROP TABLE IF EXISTS `limits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `limits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uri` varchar(255) NOT NULL,
  `count` int(10) NOT NULL,
  `hour_started` int(11) NOT NULL,
  `api_key` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `limits`
--

LOCK TABLES `limits` WRITE;
/*!40000 ALTER TABLE `limits` DISABLE KEYS */;
/*!40000 ALTER TABLE `limits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_attempts`
--

DROP TABLE IF EXISTS `login_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_attempts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_attempts`
--

LOCK TABLES `login_attempts` WRITE;
/*!40000 ALTER TABLE `login_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session`
--

DROP TABLE IF EXISTS `session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `session` (
  `step` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `login` varchar(255) NOT NULL,
  `picture` varchar(255) NOT NULL,
  `product` varchar(255) NOT NULL,
  `description` varchar(2000) NOT NULL,
  `price` varchar(100) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session`
--

LOCK TABLES `session` WRITE;
/*!40000 ALTER TABLE `session` DISABLE KEYS */;
INSERT INTO `session` VALUES (3,33854740,'zuxriddin_k','AgADAgADgqkxG02VYEqcpVdlBoK9CfU68w4ABE0773lh1_qBMqYBAAEC','Picture','Explorer for windows 10. For exploring files','900$','+998323234234234','Toshkent shahri, Eski shahar','Zuxriddin Kamalov','2018-10-21 16:04:03'),(1,41115623,'bekhzod_tillakhanov','','','','','','','Bekhzod Tillakhanov','2018-07-11 08:39:27'),(0,66441062,'0','AgADAgADrakxG5DKUUvI1oLiTg27gxfKtw4ABPFuYPCNIuuSn-cBAAEC','Кинг','Test','100','1111','test','Rustam ','2018-08-07 18:05:59'),(0,102641152,'futuz_admin','AgADAgADHKkxGyIAATlLYHFCFYImvdmXuqsOAAQ1g2yRl8fIqi5KBAABAg','Mustaqilligimizning 27 yilligi','Buni sotmeman shunde bervoraman','0000 so\'m','+998931234567','Uzolardan','βоγvลĉჩĉჩล ','2018-08-05 07:41:32'),(1,275465113,'1','AgADAgAD_qkxGwarcEqN3gt4BBk3KFa0tw4ABbKFGJ5Mh886gwUAAQI','asdwD','Wdfefr','265','9845984','dfwef','X Khan','2018-10-30 18:01:38'),(1,509148157,'iJakhongirmirzo','AgADAgADIqkxGwwj8UpVBn6_AAGw7014xUYOAASdj_xZ1-alvHuZBAABAg','Nothing','Cool','5000 som','8293739','Jskend','Jakhongirmirzo ','2018-08-07 13:24:54'),(5,576750448,'ShoazizB','AgADAgADWqkxG1R3OUv-FRZA2Be6Rcqytw4ABH5oH4bPNH9oi9IBAAEC','rasm','trenirovka','100','','','Shoaziz Bakhtiyorov','2018-08-05 14:17:45'),(0,598294767,'FutSoft','AgADAgADEakxGw8_IUjov-DjPdFSQSYqrQ4ABIML5fi-HMiqfjIFAAEC','Stadion','Germaniyaning Bavariya Myunxen stadioni sotiladi. Holati zo\'r. +Bonusga Noer qo\'shib beriladi','10000000$','+998999999999','O\'zbekiston','ℳaŋagεr [FutSoft] © ','2018-08-27 09:03:51');
/*!40000 ALTER TABLE `session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `email` varchar(254) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) unsigned DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) unsigned NOT NULL,
  `last_login` int(11) unsigned DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'127.0.0.1','administrator','$2a$07$SeBknntpZror9uyftVopmu61qg0ms8Qv1yV6FG.kQOSM.9QhmTo36','','admin@admin.com','',NULL,NULL,'S.rTrWSY1l.T4WfuadrLoO',1268889823,1537259063,1,'Admin','istrator','ADMIN','0');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_groups`
--

DROP TABLE IF EXISTS `users_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_groups` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uc_users_groups` (`user_id`,`group_id`),
  KEY `fk_users_groups_users1_idx` (`user_id`),
  KEY `fk_users_groups_groups1_idx` (`group_id`),
  CONSTRAINT `fk_users_groups_groups1` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `fk_users_groups_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_groups`
--

LOCK TABLES `users_groups` WRITE;
/*!40000 ALTER TABLE `users_groups` DISABLE KEYS */;
INSERT INTO `users_groups` VALUES (1,1,1),(2,1,2);
/*!40000 ALTER TABLE `users_groups` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-11  9:36:30

